file.edit(fname2)
source(fname2)